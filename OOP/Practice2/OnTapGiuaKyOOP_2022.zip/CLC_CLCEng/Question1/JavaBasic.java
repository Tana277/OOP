public class JavaBasic{
    public static sumNegativeElements(int arr[]){
        //code here
    }

    public static String uppercaseFirstVowels(String str){
        //code here
    }
	
	public static int findMinNegativeElement(int a[]){
        //code here
    }
	
	public static String getName(String str){
        //code here
    }

    public static int findFirstMod3Element(int[] a){
        //code here
    }

    public static int countString(String str, String k){
        //code here
    }

    public static void main(String[] args){
        int a = {1,-2,3,4,-2,1,-9};
        String s = "nguyen thi uyen an";
		String s1 = "Name: Le Thi Thu Thao";
        String s2 = "Nguyen Thi Oanh Oanh"
        //Test all of methods which you implemented
    }

}