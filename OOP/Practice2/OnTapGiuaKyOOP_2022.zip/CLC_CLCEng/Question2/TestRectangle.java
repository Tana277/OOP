class TestRectangle {
    public static void main(String[] args){
        Rectangle rec = new Rectangle("Ruby", "Red", 6, 8);       
        System.out.println(rec.getType());
        System.out.println(rec.toString());
        //Test all of methods which you implemented
    }
}
