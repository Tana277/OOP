public class Rectangle{
    private String name;
    private String color;
    private double width;
    private double length;

    public Rectangle(String name, String color, double wid, double len){
        //code here
    }

    public String getName(){
        //code here and correct the return value
        return "";
    }

    public String getColor(){
        //code here and correct the return value
        return "";
    }

    public double getWidth(){
        //code here and correct the return value
        return -1;
    }
    public double getLength(){
        //code here and correct the return value
        return -1;
    }

    public void setName(String name){
        //code here
    }

    public void setColor(String color){
        //code here
    }

    public void setWidth(double width){
        //code here
    }

    public void setLength(double length){
        //code here
    }

    public double getPerimeter(){
        //code here and correct the return value
        return -1;
    }

    public String getType(){
        //code here and correct the return value
        return "";
    }
	
	public boolean isSquare(){
        //code here and correct the return value
        return false;
    }

    public double calDiagonalLine(){
        //code here and correct the return value
        return -1;
    }

    public Rectangle resize(double rate){
         //code here and correct the return value
         return null;
    }

    public String toString(){
        //code here and correct the return value
        return "";
    }
}